export RTE_SDK=/work/home/rkwiles/projects/intel/dpdk.org
export RTE_TARGET=x86_64-native-linuxapp-clang
