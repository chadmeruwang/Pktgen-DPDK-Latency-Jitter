reset
stty sane
echo "[1;r"
echo "[2J"
