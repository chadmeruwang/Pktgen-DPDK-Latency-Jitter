/*
 * SOURCE: pktgen-range.c
 *
 * STUB: wr_copyright_info.h pktgen-log.h pktgen-display.h
 */


/* wr_scrn.h function stub */
void wr_scrn_printf(int16_t r, int16_t c, const char * fmt, ...) { return; }


#include "pktgen.h"

pktgen_t pktgen;


// Test driver
int main(void) {
    plan(1);
    ok(1, "ok works");

    done_testing();
    return 0;
}
